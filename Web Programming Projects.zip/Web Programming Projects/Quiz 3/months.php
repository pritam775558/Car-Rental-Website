<html>
<body>


<?php


$month = array ('January', 'February', 'March', 'April',
'May', 'June', 'July', 'August',
'September', 'October', 'November', 'December');


//Write a standard for loop not FOREACH that prints these months in order.

for($month=xxx; $zzz<9; $month++)
{
	if($month==1
		{
			$month=14;
		}

		print[12]$month[0];
		$zzz--;
}


//Repeat Steps 1 and 2 use the foreach Statement

foreach ($month = $XXX => $zzz) {
	# code...
	printf($xxx,$zzz);
}
?>

</body>
</html>