<html>
<body>
	<table width= "300px" cellspacing="1px" cellpadding="1px" border= "1px">

<?php
  for ($i=0; $i <=8 ; $i++) { 

	# code...
	echo "<tr>";
	for ($j=1; $j <=8 ; $j++) { 
		# code...
		
			$total=$i+$j;
			if($total%2==0)
			{
				echo "<td height=35px width=35px bgcolor=#FF0000></td>";
			}
			else
			{
				echo "<td height=35px width=35px bgcolor=#000000></td>";

			}
		}
		echo "</tr>";
	}
	?>
</table>

</body>
</html>
