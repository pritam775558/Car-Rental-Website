<html>
<body>

<?php

private function isBitten(50%,50%)

 function rand(50%,50%)

	if (this->isBitten >50%,50%)
	{
		echo "Charlie ate my lunch"
	}
	else
	{
		echo "Charlie did not eat my lunch"
	}

}

?>

</body>
</html>