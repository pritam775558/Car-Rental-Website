<html>
<body>
	<?php

		session_start();

		include("config.php");

			if (isset($_POST["login"])){
				if ( $_POST["user"] == "" || $_POST["pass"] == "" ){
					$message = "Invalid inputs";
							}else{
							$username = $_POST["user"];
							$password = $_POST["pass"];
							$sql = "SELECT name FROM agency WHERE username = '$username' AND password = '$password'";
							$result = $conn->query($sql);

								if ($result->num_rows > 0){
								while($row = $result->fetch_assoc()){
									$_SESSION["namename"] = $row["name"];
									echo "Login Successful. Below is the Exam Topic you choosed, answer these question:";
									print '<p>Question 1: Who is the President of The United States Now?</p>';
									print '<input type="radio" uncheck="uncheck" name="answer1" value="a"/>Hilary Clinton<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer2" value="b"/>Donald Trump<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer3" value="b"/>Barack Obama<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer4" value="b"/>Michele Obama<br/>';

									print '<p>Question 2: How many states are there?</p>';
									print '<input type="radio" uncheck="uncheck" name="answer1" value="a"/>45<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer2" value="b"/>70<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer3" value="b"/>50<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer4" value="b"/>20<br/>';

									print '<p>Question 3: Who is the famous guy in US $100 Dollar Bill?</p>';
									print '<input type="radio" uncheck="uncheck" name="answer1" value="a"/>Benjamin Franklin<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer2" value="b"/>Abrahim Lincoln<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer3" value="b"/>Barack Obama<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer4" value="b"/>Alexander Hamilton<br/>';

									print '<p>Question 4: How many senators are there in Congress?</p>';
									print '<input type="radio" uncheck="uncheck" name="answer1" value="a"/>50<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer2" value="b"/>60<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer3" value="b"/>80<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer4" value="b"/>100<br/>';

									print '<p>Question 5: When do we celebrate independence day?</p>';
									print '<input type="radio" uncheck="uncheck" name="answer1" value="a"/>7 October<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer2" value="b"/>5 May<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer3" value="b"/>4 July<br/>';
									print '<input type="radio" uncheck="uncheck" name="answer4" value="b"/>22 Feb<br/>';


									print '<input type="SUBMIT" name="SUBMIT"';



									
									}



								}


							else{
								echo "Username and Password does not match. Please login with correct username and password to take the Exam";
							}






				}
			}

		?>
</body>
</html>