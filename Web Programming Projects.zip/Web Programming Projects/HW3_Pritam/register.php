<html>
<body>
			<?php
			include("config.php");
			if (isset($_POST["register"])){
					if ($_POST["name"] == "" || $_POST["user"] == "" || $_POST["pass"] == ""){
							echo "Fill in all blanks";
					}
					else{
							$name = $_POST["name"];
							$username = $_POST["user"];
							$password = $_POST["pass"];
							$sql = "INSERT INTO agency(name, username, password) VALUES ('$name', '$username', '$password')";
							if ($conn->query($sql)===TRUE){
								echo "New Record Updated";
							}
							else{
								echo "Record Not Updated";
							}
					}
			}


		?>
	</body>
	</html>