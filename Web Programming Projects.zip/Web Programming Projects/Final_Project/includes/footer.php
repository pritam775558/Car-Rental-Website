	<li class="about">
					<p>The DRI>E team is an organized company that rents luxury cars and other vehicles to clients at lower costs. We we are here to serve clients of every background who want to ride around in style</p>
					<ul>
						<li><a href="#" class="facebook" target="_blank"></a></li>
						<li><a href="#" class="twitter" target="_blank"></a></li>
						<li><a href="#" class="google" target="_blank"></a></li>
						<li><a href="#" class="skype"></a></li>
					</ul>
				</li>
			</ul>
		</div>

		<div class="copyrights wrapper">
			Copyright &copy; <?php echo date("Y")?> All Rights Reserved | POWERED by <a href= "#">DRI>E</a>
		</div>
	</footer>
	
</body>
</html>