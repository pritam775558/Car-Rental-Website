<!Doctype html>
<html>
	<head>
		<title>Login to your Account</title>


		<?php
		session_start();
		include("config.php");

			if (isset($_POST["login"])){
				if ( $_POST["user"] == "" || $_POST["pass"] == "" ){
					$message = "Invalid inputs";
					echo "<script type='text/javascript'>alert('$message');</script>";
					echo '<br><a href="login.html" class="button">Go back to Login</a><br>
								<a href="register.html" class="button">New Account?</a>';
				}else{
							

							$username = $_POST["user"];
							$password = $_POST["pass"];

							$sql = "SELECT name FROM user WHERE username = '$username' AND password = '$password'";

							$result = $conn->query($sql);

							if ($result->num_rows > 0){
								while($row = $result->fetch_assoc()){
					
									$_SESSION["namename"] = $row["name"];
									echo "Welcome to your Account " . $row["name"]. ",<br>";
									echo '<p><a href="logout.php">Logout</a></p>';
								}
							}
							else{
								echo "Username and Password does not match";
							}


				}
			}

		?>



	</body>
</html>
