<?php
	session_start();
	session_destroy();
	unset($_SESSION['username']);
	$_SESSION['message'] = "Logged out of you Account";
	header("location: index.html");

?>
